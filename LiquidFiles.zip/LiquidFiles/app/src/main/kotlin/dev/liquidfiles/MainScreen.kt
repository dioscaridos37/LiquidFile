package dev.liquidfiles

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Tabs = listOf(
    TabSpec("Главная", Icons.Rounded.Home),
    TabSpec("Файлы", Icons.Rounded.Folder),
    TabSpec("Недавние", Icons.Rounded.History),
    TabSpec("Настройки", Icons.Rounded.Settings),
)

@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val motion = LocalMotion.current
    val haptic = LocalHapticFeedback.current
    val s = vm.settings
    val layer = rememberGraphicsLayer()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var lastDlg by remember { mutableStateOf<Dlg?>(null) }
    if (dlg != null) lastDlg = dlg
    var lastMsg by remember { mutableStateOf("") }
    vm.message?.let { lastMsg = it }
    val selecting = vm.selection.isNotEmpty()

    LaunchedEffect(vm.message) { if (vm.message != null) { delay(2600); vm.message = null } }
    LaunchedEffect(tab) {
        if (tab == 2) vm.loadRecent()
        if (tab == 0) vm.loadStorage()
    }

    BackHandler(enabled = dlg != null || tab != 0) {
        when {
            dlg != null -> dlg = null
            tab == 1 -> if (!vm.goUp()) tab = 0
            else -> tab = 0
        }
    }

    fun tick() { if (s.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    CompositionLocalProvider(LocalBackdrop provides layer) {
        Box(Modifier.fillMaxSize()) {

            // ---------- задний план: обои + экраны (его запоминает слой для размытия стекла) ----------
            Box(
                Modifier.fillMaxSize().drawWithContent {
                    layer.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
                        this@drawWithContent.drawContent()
                    }
                    drawLayer(layer)
                }
            ) {
              // Внутри самого «заднего плана» стекло не должно читать этот же слой.
              CompositionLocalProvider(LocalBackdrop provides null) {
                Wallpaper()
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(motion.spec()) { it / 5 * dir } +
                            fadeIn(tween(220)) + scaleIn(motion.spec(), initialScale = 0.96f)) togetherWith
                            (slideOutHorizontally(motion.spec()) { -it / 6 * dir } + fadeOut(tween(160)))
                    },
                    label = "tabs",
                ) { t ->
                    when (t) {
                        0 -> HomeScreen(
                            vm,
                            onCategory = { vm.openCategory(it); tab = 1 },
                            onFolder = { vm.openDir(it); tab = 1 },
                        )
                        1 -> FileCollection(
                            entries = vm.entries,
                            grid = s.gridMode,
                            selection = vm.selection,
                            topPad = statusTop + 80.dp,
                            bottomPad = 190.dp,
                            loading = vm.loading,
                            onClick = { e ->
                                when {
                                    selecting -> vm.toggle(e.file)
                                    e.isDir -> vm.openDir(e.file)
                                    else -> openFile(ctx, e.file) { vm.message = it }
                                }
                            },
                            onLong = { e -> tick(); vm.toggle(e.file) },
                        )
                        2 -> Column(Modifier.fillMaxSize()) {
                            Box(Modifier.padding(start = 16.dp, top = statusTop + 16.dp, bottom = 8.dp)) {
                                T("Недавние", size = 34.sp, weight = FontWeight.Bold)
                            }
                            Box(Modifier.weight(1f)) {
                                FileCollection(
                                    entries = vm.recent, grid = false, selection = emptySet(),
                                    topPad = 4.dp, bottomPad = 160.dp, loading = false,
                                    onClick = { e -> openFile(ctx, e.file) { vm.message = it } },
                                    onLong = { e -> shareFiles(ctx, listOf(e.file)) { vm.message = it } },
                                )
                            }
                        }
                        else -> SettingsScreen(vm)
                    }
                }
              }
            }

            // ---------- верхняя стеклянная панель (только «Файлы») ----------
            AnimatedVisibility(
                visible = tab == 1,
                modifier = Modifier.align(Alignment.TopCenter),
                enter = slideInVertically(motion.spec()) { -it } + fadeIn(tween(150)),
                exit = slideOutVertically(motion.spec()) { -it } + fadeOut(tween(120)),
            ) { FilesTopBar(vm) { dlg = Dlg.Sort } }

            // ---------- нижняя «хромированная» зона ----------
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 10.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                AnimatedVisibility(
                    visible = vm.message != null,
                    enter = scaleIn(motion.spec(), initialScale = 0.7f) + fadeIn(tween(120)),
                    exit = fadeOut(tween(200)),
                ) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        GlassSurface(shape = CircleShape, alpha = 0.7f) {
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) { T(lastMsg, size = 14.sp) }
                        }
                    }
                }

                AnimatedVisibility(
                    visible = tab == 1 && !selecting && vm.category == null,
                    enter = scaleIn(motion.spec(), initialScale = 0.5f) + fadeIn(tween(150)),
                    exit = scaleOut(motion.spec(), targetScale = 0.5f) + fadeOut(tween(120)),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (vm.clipboard.isNotEmpty()) {
                            GlassSurface(
                                Modifier.height(52.dp).bouncy { vm.paste() },
                                shape = CircleShape, blur = false,
                                tint = MaterialTheme.colorScheme.primary, alpha = 0.9f,
                            ) {
                                Row(Modifier.padding(horizontal = 18.dp).fillMaxHeight(), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.ContentPaste, null, tint = Color.White, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    T("Вставить (${vm.clipboard.size})", size = 15.sp, weight = FontWeight.SemiBold, color = Color.White)
                                }
                            }
                            GlassIconButton(Icons.Rounded.Close, { vm.clearClipboard() }, size = 44)
                        }
                        GlassSurface(
                            Modifier.size(56.dp).bouncy { dlg = Dlg.Create },
                            shape = CircleShape, blur = false,
                            tint = MaterialTheme.colorScheme.primary, alpha = 0.95f,
                        ) { Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(28.dp)) }
                    }
                }

                AnimatedContent(
                    targetState = selecting,
                    transitionSpec = {
                        (slideInVertically(motion.spec()) { it / 2 } + fadeIn(tween(160)) + scaleIn(motion.spec(), initialScale = 0.9f)) togetherWith
                            (slideOutVertically(motion.spec()) { it / 2 } + fadeOut(tween(120)))
                    },
                    label = "bar",
                ) { sel ->
                    if (sel) SelectionBar(
                        onCopy = { vm.copySelected() },
                        onCut = { vm.cutSelected() },
                        onDelete = { dlg = Dlg.Delete(vm.selection.toList()) },
                        onShare = { shareFiles(ctx, vm.selection.toList()) { vm.message = it } },
                        onMore = { dlg = Dlg.More(vm.selection.toList()) },
                    ) else LiquidSwitcher(
                        items = Tabs, selected = tab,
                        onSelect = { if (it != tab) tab = it },
                    )
                }
            }

            // ---------- диалоги ----------
            GlassDialog(visible = dlg != null, onDismiss = { dlg = null }) {
                val close = { dlg = null }
                when (val d = lastDlg) {
                    Dlg.Create -> {
                        T("Создать", size = 20.sp, weight = FontWeight.SemiBold)
                        ActionRow(Icons.Rounded.CreateNewFolder, "Папку") { dlg = Dlg.NewFolder }
                        ActionRow(Icons.Rounded.NoteAdd, "Файл") { dlg = Dlg.NewFile }
                    }
                    Dlg.NewFolder -> PromptDialogBody("Новая папка", "", "Создать", { vm.newFolder(it); close() }, close)
                    Dlg.NewFile -> PromptDialogBody("Новый файл", "", "Создать", { vm.newFile(it); close() }, close)
                    is Dlg.Rename -> PromptDialogBody("Переименовать", d.f.name, "ОК", { vm.rename(d.f, it); close() }, close)
                    is Dlg.Delete -> ConfirmBody(
                        "Удалить?", "Безвозвратно удалить элементов: ${d.files.size}", "Удалить",
                        { vm.delete(d.files); close() }, close,
                    )
                    is Dlg.Info -> InfoBody(d.f, close)
                    Dlg.Sort -> SortBody(vm.settings, { t -> vm.update(t) }, close)
                    is Dlg.More -> {
                        val one = d.files.singleOrNull()
                        T("Ещё", size = 20.sp, weight = FontWeight.SemiBold)
                        if (one != null) ActionRow(Icons.Rounded.Edit, "Переименовать") { dlg = Dlg.Rename(one) }
                        if (one != null) ActionRow(Icons.Rounded.Info, "Свойства") { dlg = Dlg.Info(one) }
                        ActionRow(Icons.Rounded.FolderZip, "В архив ZIP") { vm.zipSelected(); close() }
                        if (one != null && one.extension.lowercase() == "zip") {
                            ActionRow(Icons.Rounded.Unarchive, "Распаковать") { vm.unzip(one); close() }
                        }
                        ActionRow(Icons.Rounded.SelectAll, "Выбрать всё") { vm.selectAll(); close() }
                    }
                    null -> {}
                }
            }
        }
    }
}

@Composable
private fun FilesTopBar(vm: MainViewModel, onSort: () -> Unit) {
    val s = vm.settings
    val accent = MaterialTheme.colorScheme.primary
    val focus = remember { FocusRequester() }
    LaunchedEffect(vm.searching) { if (vm.searching) focus.requestFocus() }
    val selecting = vm.selection.isNotEmpty()
    val title = when {
        selecting -> "Выбрано: ${vm.selection.size}"
        vm.category != null -> vm.category!!.title
        vm.atRoot -> "Внутренняя память"
        else -> vm.currentDir.name
    }

    GlassSurface(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp).height(58.dp),
        shape = RoundedCornerShape(29.dp),
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selecting || vm.searching || !vm.atRoot) {
                GlassIconButton(
                    if (selecting || vm.searching) Icons.Rounded.Close else Icons.Rounded.ArrowUpward,
                    { vm.goUp() }, size = 42,
                )
                Spacer(Modifier.width(8.dp))
            } else Spacer(Modifier.width(10.dp))

            if (vm.searching && !selecting) {
                BasicTextField(
                    value = vm.query, onValueChange = { vm.onQuery(it) }, singleLine = true,
                    textStyle = TextStyle(color = ink(), fontSize = 17.sp),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.weight(1f).focusRequester(focus),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (vm.query.isEmpty()) T("Поиск в папке", size = 17.sp, color = inkSoft())
                            inner()
                        }
                    },
                )
            } else {
                T(title, size = 19.sp, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            }

            if (!selecting && !vm.searching) {
                if (vm.category == null) GlassIconButton(Icons.Rounded.Search, { vm.startSearch() }, size = 40)
                Spacer(Modifier.width(6.dp))
                GlassIconButton(
                    if (s.gridMode) Icons.Rounded.ViewAgenda else Icons.Rounded.GridView,
                    { vm.update { it.copy(gridMode = !it.gridMode) } }, size = 40,
                )
                Spacer(Modifier.width(6.dp))
                GlassIconButton(Icons.Rounded.SwapVert, onSort, size = 40)
            }
        }
    }
}

@Composable
private fun SelectionBar(onCopy: () -> Unit, onCut: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit, onMore: () -> Unit) {
    GlassSurface(Modifier.fillMaxWidth().height(76.dp), shape = RoundedCornerShape(50)) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            SelAction(Icons.Rounded.ContentCopy, "Копия", onClick = onCopy)
            SelAction(Icons.Rounded.ContentCut, "Вырезать", onClick = onCut)
            SelAction(Icons.Rounded.Delete, "Удалить", tint = Color(0xFFE5484D), onClick = onDelete)
            SelAction(Icons.Rounded.Share, "Отправить", onClick = onShare)
            SelAction(Icons.Rounded.MoreVert, "Ещё", onClick = onMore)
        }
    }
}

@Composable
private fun SelAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color = ink(), onClick: () -> Unit) {
    Column(Modifier.bouncy(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        T(label, size = 11.sp, color = tint.copy(alpha = 0.85f))
    }
}
