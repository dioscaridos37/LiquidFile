package dev.liquidfiles

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

sealed interface Dlg {
    data object Create : Dlg
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val f: File) : Dlg
    data class Delete(val files: List<File>) : Dlg
    data class Info(val f: File) : Dlg
    data object Sort : Dlg
    data class More(val files: List<File>) : Dlg
}

/** Диалог внутри той же композиции: стекло видит фон и «выпрыгивает» пружиной. */
@Composable
fun GlassDialog(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val motion = LocalMotion.current
    AnimatedVisibility(visible, enter = fadeIn(motion.spec()), exit = fadeOut(motion.spec())) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.32f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
            contentAlignment = Alignment.Center,
        ) {
            GlassSurface(
                Modifier.padding(26.dp).widthIn(max = 380.dp).fillMaxWidth()
                    .animateEnterExit(
                        enter = scaleIn(motion.spec(), initialScale = 0.78f) + fadeIn(motion.spec()),
                        exit = scaleOut(motion.spec(), targetScale = 0.85f) + fadeOut(motion.spec()),
                    )
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                shape = RoundedCornerShape(32.dp), alpha = 0.72f,
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
            }
        }
    }
}

@Composable
fun GlassButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, primary: Boolean = false, danger: Boolean = false) {
    val bg = when { danger -> Color(0xFFE5484D); primary -> MaterialTheme.colorScheme.primary; else -> null }
    GlassSurface(
        modifier.height(46.dp).bouncy(onClick = onClick),
        shape = CircleShape, blur = false, shadow = false, tint = bg, alpha = if (bg != null) 0.95f else null,
    ) {
        Box(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentAlignment = Alignment.Center) {
            T(text, size = 15.sp, weight = FontWeight.SemiBold, color = if (bg != null) Color.White else ink())
        }
    }
}

@Composable
fun ActionRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().bouncy(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        T(label, size = 16.sp)
    }
}

@Composable
fun PromptDialogBody(title: String, initial: String, ok: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    T(title, size = 20.sp, weight = FontWeight.SemiBold)
    OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
        GlassButton("Отмена", onCancel)
        GlassButton(ok, { if (text.isNotBlank()) onOk(text) }, primary = true)
    }
}

@Composable
fun ConfirmBody(title: String, text: String, ok: String, onOk: () -> Unit, onCancel: () -> Unit) {
    T(title, size = 20.sp, weight = FontWeight.SemiBold)
    T(text, size = 15.sp, color = inkSoft(), maxLines = 4)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
        GlassButton("Отмена", onCancel)
        GlassButton(ok, onOk, danger = true)
    }
}

@Composable
fun InfoBody(f: File, onClose: () -> Unit) {
    val stats by produceState<Pair<Long, Int>?>(null, f) { value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { FileOps.folderStats(f) } }
    T("Свойства", size = 20.sp, weight = FontWeight.SemiBold)
    T(f.name, size = 16.sp, weight = FontWeight.SemiBold, maxLines = 3)
    T(f.parent ?: "", size = 13.sp, color = inkSoft(), maxLines = 3)
    T("Размер: " + (stats?.let { formatSize(it.first) } ?: "считаю…"), size = 14.sp)
    if (f.isDirectory) T("Файлов внутри: " + (stats?.second?.toString() ?: "…"), size = 14.sp)
    T("Изменён: ${formatDate(f.lastModified())}", size = 14.sp)
    T("Тип: " + if (f.isDirectory) "папка" else FileOps.mimeOf(f), size = 14.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { GlassButton("Закрыть", onClose, primary = true) }
}

@Composable
fun SortBody(s: AppSettings, onChange: ((AppSettings) -> AppSettings) -> Unit, onClose: () -> Unit) {
    T("Сортировка", size = 20.sp, weight = FontWeight.SemiBold)
    LiquidSwitcher(
        items = listOf(TabSpec("Имя"), TabSpec("Размер"), TabSpec("Дата"), TabSpec("Тип")),
        selected = s.sortBy, onSelect = { i -> onChange { it.copy(sortBy = i) } },
        height = 52.dp, textSize = 13.sp,
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        T("По убыванию", size = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = s.sortDesc, onCheckedChange = { v -> onChange { it.copy(sortDesc = v) } })
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        T("Папки сверху", size = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = s.foldersFirst, onCheckedChange = { v -> onChange { it.copy(foldersFirst = v) } })
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { GlassButton("Готово", onClose, primary = true) }
}
