package dev.liquidfiles

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/** Слой с «задним планом» (обои + контент). Стеклянные панели берут из него картинку и размывают её. */
val LocalBackdrop = staticCompositionLocalOf<GraphicsLayer?> { null }

/**
 * Жидкое стекло: реальное размытие того, что находится ПОД панелью,
 * полупрозрачная градиентная заливка, светящийся ободок и мягкая тень.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(LocalAppSettings.current.corner.dp),
    blur: Boolean = true,
    shadow: Boolean = true,
    tint: Color? = null,
    alpha: Float? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val s = LocalAppSettings.current
    val dark = LocalDark.current
    val backdrop = LocalBackdrop.current
    val blurLayer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val base = tint ?: if (dark) Color(0xFF2A2A32) else Color.White
    val a = alpha ?: s.glassAlpha

    Box(
        modifier
            .then(
                if (shadow) Modifier.shadow(
                    10.dp, shape, clip = false,
                    ambientColor = Color.Black.copy(alpha = 0.10f),
                    spotColor = Color.Black.copy(alpha = 0.16f),
                ) else Modifier
            )
            .onGloballyPositioned { pos = it.positionInRoot() }
            .drawBehind {
                val outline = shape.createOutline(size, layoutDirection, this)
                val path = Path().apply { addOutline(outline) }
                val r = s.blur * density
                if (blur && backdrop != null && r > 0.5f && size.width >= 1f && size.height >= 1f) {
                    blurLayer.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                    blurLayer.record(this, layoutDirection, IntSize(size.width.toInt(), size.height.toInt())) {
                        translate(-pos.x, -pos.y) { drawLayer(backdrop) }
                    }
                    clipPath(path) { drawLayer(blurLayer) }
                }
                clipPath(path) {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(
                                base.copy(alpha = (a * 1.2f).coerceAtMost(1f)),
                                base.copy(alpha = (a * 0.8f).coerceAtMost(1f)),
                            )
                        )
                    )
                }
                drawPath(
                    path,
                    brush = Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = if (dark) 0.38f else 0.95f),
                            Color.White.copy(alpha = 0.06f),
                            Color.White.copy(alpha = if (dark) 0.22f else 0.65f),
                        ),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height),
                    ),
                    style = Stroke(1.3.dp.toPx()),
                )
            },
        content = content,
    )
}

/** Упругое нажатие: кнопка проваливается и «выпрыгивает» обратно по пружине. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.bouncy(
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val motion = LocalMotion.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = motion.spec<Float>(Spring.StiffnessMedium),
        label = "bouncy",
    )
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .combinedClickable(
            interactionSource = src, indication = null, enabled = enabled,
            onLongClick = onLongClick, onClick = onClick,
        )
}

@Composable
fun GlassIconButton(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = ink(), size: Int = 44) {
    GlassSurface(
        modifier.size(size.dp).bouncy(onClick = onClick),
        shape = CircleShape, blur = false, shadow = false,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.align(Alignment.Center).size((size * 0.5f).dp))
    }
}
